//
//  Grid16App.swift
//  Grid16
//
//  Created by Zachary Fertig on 4/15/21.
//

import SwiftUI

@main
struct Grid16App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
