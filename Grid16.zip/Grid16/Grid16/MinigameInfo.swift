//
//  MinigameInfo.swift
//  Grid16
//
//  Created by Zachary Fertig on 5/11/21.
//

import SwiftUI

struct MinigameInfo: View {
    var body: some View {
        NavigationView {
//            List(emojis.emojiList) { emojiItem in
//                NavigationLink(destination: DetailsView(emojiItem: emojiItem))
//                {
//                    HStack {
//                        EmojiCircleView(emojiItem: emojiItem)
//                        Text(emojiItem.name)
//                            .font(.headline)
//                    }
//                }
//            }
//            .navigationBarTitle("MiniGames")
        }
    }
}

struct MinigameInfo_Previews: PreviewProvider {
    static var previews: some View {
        MinigameInfo()
    }
}
