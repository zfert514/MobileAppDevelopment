//
//  ShipPoint.swift
//  Ships
//
//  Created by Zachary Fertig on 4/12/21.
//

import SpriteKit

struct ShipPoint {
    var position: CGPoint
    var zRotation: CGFloat
}
