//
//  ShipsApp.swift
//  Ships
//
//  Created by Joel Hollingsworth on 4/4/21.
//

import SwiftUI

@main
struct ShipsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
