//
//  UnacceptedPassword.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/19/21.
//

import SwiftUI

struct UnacceptedPassword: View {
    
    var tries: String
    var numAndPos: String
    var nums: String
    
    var body: some View {
        VStack {
            Text("Incorrect Password")
                .font(.largeTitle)
                .bold()
                .padding()
            if (tries == "10" || tries == "0"){
                Text("Locked Out")
                    .font(.title)
                    .bold()
                    .padding()
                Text("Try Again?")
                    .font(.title)
                    .bold()
                    .padding()
            }
            else {
                Text("Attempt #\(tries)/10")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                HStack {
                    Text("Correct Number: \(nums)")
                        .font(.title)
                        .bold()
                        .padding()
                    Text("Correct Position: \(numAndPos)")
                        .font(.title)
                        .bold()
                        .padding()
                }
            }
            
        }
        Spacer()
    }
}

struct UnacceptedPassword_Previews: PreviewProvider {
    static var previews: some View {
        UnacceptedPassword(tries: String(), numAndPos: String(), nums: String())
    }
}
