//
//  AcceptedPassword.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/19/21.
//

import SwiftUI

struct AcceptedPassword: View {
    
    var password: String
    
    var body: some View {
        VStack {
            Text("Password:")
                .font(.largeTitle)
                .bold()
                .padding()
            Text(password)
                .font(.largeTitle)
                .bold()
                .padding()
            Text("New Password?")
                .font(.title)
                .bold()
                .padding()
        }
        Spacer()
    }
}

struct AcceptedPassword_Previews: PreviewProvider {
    static var previews: some View {
        AcceptedPassword(password: String())
    }
}
