//
//  TopSecretApp.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/18/21.
//

import SwiftUI

@main
struct TopSecretApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(topSecret: TopSecret())
        }
    }
}
