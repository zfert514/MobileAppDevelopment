//
//  Password.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/18/21.
//

import Foundation

struct Password {
    
    var passwordLength = 4
    var password = Array<String>()
    
    init() {
        for _ in 1...passwordLength {
            let num = getRandomNumber(range: passwordLength)
            password.append(String(num))
        }
        print(password)
    }
    
    func getRandomNumber(range: Int) -> Int {
        return Int.random(in: 1..<range)
    }
    
    func arrayToString() -> String {
        var string = ""
        for num in password {
            string = "\(string)\(num)"
        }
        return string
    }
    
    func isGuessCorrect(guess: String) -> Bool {
        if (arrayToString() == guess) {
            return true
        }
        return false
    }
    
    func numAndPositionsCorrect(guess: Array<String>) -> Int {
        var count = 0
        for index in 0..<passwordLength {
            if (password[index] == guess[index]) {
                count += 1
            }
        }
        return count
    }
    
    func numsCorrect(guess: Array<String>) -> Int {
        var tempPass = password
        var count = 0
        for i in 0..<guess.count {
            for j in 0..<guess.count {
                if (tempPass[i] == guess[i]) {
                    count += 1
                    tempPass[i] = ""
                    break
                }
                if (tempPass[j] == guess[i]) {
                    count += 1
                    tempPass[j] = ""
                    break
                }
            }
        }
        return count
    }
    
    mutating func reset() {
        for index in 0..<passwordLength {
            let num = getRandomNumber(range: passwordLength)
            password[index] = String(num)
        }
        print(password)
    }
}
