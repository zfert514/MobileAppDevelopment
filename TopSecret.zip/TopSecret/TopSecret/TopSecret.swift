//
//  TopSecret.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/18/21.
//

import Foundation

class TopSecret: ObservableObject {
    
    //model
    var password = ""
    var tries = 0
    var pass = Password()
    @Published var guess = Guess()
    
    //MARK: - Access to the Model
    func getGuess() -> String {
        return guess.arrayToString()
    }
    
    func getPassword() -> String {
        return pass.arrayToString()
    }
    
    func getPositionsCorrect() -> String {
        return String(pass.numAndPositionsCorrect(guess: guess.guess))
    }
    
    func getNumsCorrect() -> String {
        return String(pass.numsCorrect(guess: guess.guess))
    }
    
    // MARK: - Actions (Intents)
    func tapNumber(input: String) {
        guess.addToGuess(input: input)
    }
    
    func tapClear() {
        guess.clearGuess()
    }
    
    func tapEnter() -> Int {
        if (guess.guessFull()) {
            tries += 1
            if(pass.isGuessCorrect(guess: guess.arrayToString())) {
                password = pass.arrayToString()
                reset()
                return 1
            }
            if(tries >= 10){
                reset()
            }
            return 2
        }
        return 0
    }
    
    func reset() {
        guess.clearGuess()
        pass.reset()
        tries = 0
    }
}
