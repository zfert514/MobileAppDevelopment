//
//  ContentView.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/18/21.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var topSecret: TopSecret
    
    var body: some View {
        NavigationView {
            VStack{
                Text("Password")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                HStack{
                    InputButton(topSecret: topSecret, label: "1")
                    InputButton(topSecret: topSecret, label: "2")
                }
                HStack{
                    InputButton(topSecret: topSecret, label: "3")
                    InputButton(topSecret: topSecret, label: "4")
                }
                GuessText(topSecret: topSecret)
                HStack {
                    ClearButton(topSecret: topSecret)
                    EnterButton(topSecret: topSecret)
                    
                }
            }
        }
    }
}

struct ClearButton: View {
    
    @ObservedObject var topSecret: TopSecret
    
    var body: some View {
        Button(action: {
            topSecret.tapClear()
        }, label: {
            Text("Clear")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.black, lineWidth: 3))
        })
        .padding()
    }
}

struct EnterButton: View {
    
    @ObservedObject var topSecret: TopSecret
    @State private var action: Int? = 0
    
    var body: some View {
        NavigationLink(destination: AcceptedPassword(password: topSecret.password), tag: 1, selection: $action) {
            EmptyView()
        }
        NavigationLink(destination: UnacceptedPassword(tries: String(topSecret.tries), numAndPos: topSecret.getPositionsCorrect(), nums: topSecret.getNumsCorrect()), tag: 2, selection: $action) {
            EmptyView()
        }
        Button(action: {
            self.action = topSecret.tapEnter()
        }, label: {
            Text("Enter")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.black, lineWidth: 3))
        })
        .padding()
    }
}

struct GuessText: View {
    
    @ObservedObject var topSecret: TopSecret
    
    var body: some View {
        Text(topSecret.getGuess())
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(.black)
            .padding(20)
    }
}

struct InputButton: View {
    
    @ObservedObject var topSecret: TopSecret
    var label: String
    
    var body: some View {
        Button(action: {
            topSecret.tapNumber(input: label)
        }, label: {
            Text(label)
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.black)
                .padding(40)
                .overlay(
                    Circle()
                        .stroke(Color.black, lineWidth: 3))
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(topSecret: TopSecret())
    }
}
