//
//  Guess.swift
//  TopSecret
//
//  Created by Zachary Fertig on 3/18/21.
//

import Foundation

struct Guess {
    
    var passwordLength = 4
    var guess = Array<String>()
    
    init() {
        for _ in 1...passwordLength {
            guess.append("*")
        }
        print(guess)
    }
    
    func arrayToString() -> String {
        var string = ""
        for num in guess {
            string = "\(string)\(num)"
        }
        return string
    }
    
    mutating func addToGuess(input: String) {
        for index in 0..<passwordLength {
            if(guess[index] == "*") {
                guess[index] = input
                break
            }
        }
        print(guess)
    }
    
    mutating func clearGuess() {
        for index in 0..<passwordLength {
            guess[index] = "*"
        }
        print(guess)
    }
    
    func guessFull() -> Bool {
        for index in 0..<passwordLength {
            if(guess[index] == "*") {
                return false
            }
        }
        return true
    }
}
