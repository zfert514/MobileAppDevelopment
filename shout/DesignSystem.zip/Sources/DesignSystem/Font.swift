import SwiftUI

public extension Font {
    /// Namespace to prevent naming collisions with static accessors on
    /// SwiftUI's Font.
    ///
    /// Xcode's autocomplete allows for easy discovery of design system fonts.
    /// At any call site that requires a font, type `Font.DesignSystem.<esc>`
    struct DesignSystem {
        public static let title = Font.custom("MidCentury-Regular", size: 100)
        public static let header = Font.custom("Gotham-Bold", size: 40)
        public static let page = Font.custom("MidCentury-Regular", size: 33)
        public static let bigBody = Font.custom("Gotham-Book", size: 30)
        public static let regularBody = Font.custom("Gotham-Book", size: 25)
        public static let smallBody = Font.custom("Gotham-Book", size: 20)
        public static let smallLight = Font.custom("Gotham-Light", size: 15)
    }
}
