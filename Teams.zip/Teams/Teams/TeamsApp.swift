//
//  TeamsApp.swift
//  Teams
//
//  Created by Joel Hollingsworth on 3/31/21.
//

import SwiftUI

@main
struct TeamsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
